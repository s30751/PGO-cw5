public class TestType {
    private String name;

    public TestType(String name) {
        this.name = name;
    }
}
